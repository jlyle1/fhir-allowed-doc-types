# Home - Allowed Document Types Operation v1.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/ImplementationGuide/example.fhir.allowed-document-types | *Version*:1.0.0 |
| Draft as of 2026-01-28 | *Computable Name*:AllowedDocumentTypesIG |

# Allowed Document Types Implementation Guide

This Implementation Guide defines a FHIR operation for retrieving the list of clinical document types a user is authorized to create in a given context.

## Use Case

When a SMART on FHIR application launches from an EHR, it often needs to know which document types the current user can create. This varies by:

* User role/credentials
* Location (clinic, ward, facility)
* Encounter context
* EHR-specific configuration

This IG defines the `$allowed-document-types` operation to provide a standardized, FHIR-native way to query this information.

## Target EHR Platforms

This operation is designed to be implementable as a facade over:

* **VistA** - Wrapping TIU (Text Integration Utilities) RPCs
* **Cerner/Oracle Health** - Wrapping Document Ontology APIs

## Approaches

This IG supports two approaches for retrieving allowed document types:

| | |
| :--- | :--- |
| **[$allowed-document-types](operations.md)** | FHIR operation for direct API queries |
| **[CDS Hooks](hooks.md)** | Proactive suggestions during clinical workflows |

## Quick Start

```
GET /$allowed-document-types

```

Returns a `Parameters` resource containing the document types available to the current user (derived from the access token context).

See [Operations](operations.md) for the FHIR operation details, or [CDS Hooks](hooks.md) for workflow integration.

